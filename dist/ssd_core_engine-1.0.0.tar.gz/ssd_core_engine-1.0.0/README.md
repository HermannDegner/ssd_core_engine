# SSD Core Engine - 構造主観力学 汎用AIエンジン

Hermann Degnerの[構造主観力学理論](https://github.com/HermannDegner/Structural-Subjectivity-Dynamics)の完全実装

## 📁 プロジェクト構成

効率的な開発・保守のため、機能別にフォルダー分けされています：

### 🎯 コアエンジン (ルート)
- **`ssd_types.py`** - 基本型定義・データ構造
- **`ssd_meaning_pressure.py`** - 意味圧システム  
- **`ssd_alignment_leap.py`** - 整合・跳躍システム
- **`ssd_decision.py`** - 意思決定・行動システム
- **`ssd_prediction.py`** - 予測・未来分析システム
- **`ssd_utils.py`** - ユーティリティ関数
- **`ssd_territory.py`** - 縄張りシステム（最適化版）
- **`ssd_engine.py`** - メイン統合エンジン
- **`__init__.py`** - パッケージ初期化

### 📚 [docs/](docs/) - ドキュメント
- アーキテクチャガイドライン
- 拡張機能説明

### 🧪 [tests/](tests/) - テストスイート  
- メインエンジンテスト
- 拡張機能テスト
- 縄張りシステムテスト

### 📜 [scripts/](scripts/) - ユーティリティ
- デモスクリプト
- コードチェックツール
- 詳細分析ツール

### 🗄️ [archive/](archive/) - アーカイブ
- 非推奨ファイル

## 🚀 使用方法

### 基本的な使い方

```python
# エンジンの初期化
from ssd_engine import create_ssd_engine, setup_basic_structure
from ssd_utils import create_simple_world_objects

# エンジン作成
engine = create_ssd_engine("my_agent")
setup_basic_structure(engine)

# オブジェクト作成
world_objects = create_simple_world_objects()

# シミュレーション実行
for step in range(10):
    # オブジェクト知覚
    perceived = [world_objects[0]]
    actions = ["approach", "avoid", "investigate"]
    
    # ステップ実行
    result = engine.step(perceived, actions)
    
    print(f"Decision: {result['decision']['chosen_action']}")
    print(f"Energy: {result['system_state']['energy']['E']:.2f}")
```

### 高度な機能

```python
# 未来予測
prediction = engine.predict_future_state("food_item_1")
print(f"Crisis level: {prediction.crisis_level}")

# 危機検出
crisis = engine.detect_crisis_conditions()
print(f"Crisis detected: {crisis['crisis_detected']}")

# システムヘルス監視
health = engine.get_health_status()
print(f"System health: {health['status']}")
```

## 🧠 構造主観力学理論の実装

### 四層構造システム
- **物理層（Physical）**: 絶対制約・基本法則
- **基層（Base）**: 本能・感情・生存欲求
- **中核層（Core）**: アイデンティティ・価値観・記憶
- **上層（Upper）**: 概念・理念・抽象思考

### 核心メカニズム
- **意味圧（Meaning Pressure）**: 構造に作用する変化の力
- **整合（Alignment）**: 安定維持メカニズム
- **跳躍（Leap）**: 非連続的構造変化
- **基層的色付け**: 生存関連の優先処理

## 📊 パフォーマンス特徴

- **メモリ効率**: 自動キャッシュ管理・圧縮
- **予測精度**: トレンド分析・信頼度計算
- **学習能力**: 整合慣性による経験学習
- **危機対応**: リアルタイム危機検出

## 🔧 開発者向け情報

### モジュール詳細

#### ssd_types.py
基本的なデータ構造と列挙型を定義
- `LayerType`: 四層構造の列挙型
- `ObjectInfo`: オブジェクト情報クラス
- `StructuralState`: 構造状態クラス

#### ssd_meaning_pressure.py  
意味圧処理の核心ロジック
- 数学的厳密性を持つ意味圧計算
- 類似度計算・キャッシュシステム
- 構造的相互作用の処理

#### ssd_alignment_leap.py
整合・跳躍メカニズムの実装
- 整合流計算・整合慣性更新
- 跳躍条件判定・確率的実行
- 基層的色付け統合

#### ssd_decision.py
意思決定・行動評価システム
- 生存関連行動の優先化
- 探索・活用バランス制御  
- 行動成功率学習

#### ssd_prediction.py
未来予測・危機検出システム
- トレンド分析・予測信頼度
- 多段階危機レベル判定
- キャッシュ付き高速予測

#### ssd_utils.py
ヘルパー関数・監視機能
- システム監視・診断
- メンテナンス管理
- テスト用オブジェクト生成

#### ssd_engine.py
統合エンジン・公開API
- 全モジュールの協調制御
- 統一インターフェース
- システム状態管理

## 🎯 分割のメリット

### 保守性
- 各機能が独立したファイル
- 責務が明確に分離
- バグの局所化

### 可読性  
- モジュールサイズの最適化（100-300行）
- 機能ごとの理解が容易
- ドキュメント化の簡素化

### テスト性
- モジュール単位でのテスト
- 依存関係の明確化
- デバッグの効率化

### 拡張性
- 新機能追加の容易さ
- 既存機能への影響最小化
- プラグイン的な機能追加

### 再利用性
- 必要な部分のみ使用可能
- 他プロジェクトでの部分利用
- ライブラリ化の準備

## ⚠️ 注意事項

### インポートエラーについて
現在、各モジュール間のインポートでエラーが発生する可能性があります。これを解決するには：

1. すべてのファイルが同じディレクトリにあることを確認
2. Python の PYTHONPATH にディレクトリを追加
3. または、各ファイルでパス追加コードを使用

### 使用前の準備
```bash
# ディレクトリ移動
cd ssd_core_engine

# Python パス設定
export PYTHONPATH=$PYTHONPATH:$(pwd)

# または、実行時に以下を追加
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
```

## 📝 今後の改善予定

- [ ] インポートエラーの完全解決
- [ ] 単体テストの追加
- [ ] 型ヒントの強化
- [ ] ドキュメント生成の自動化
- [ ] パフォーマンスベンチマーク
- [ ] 設定ファイル対応

## 📖 理論背景

この実装は Hermann Degner の構造主観力学理論に基づいています：
- GitHub: https://github.com/HermannDegner/Structural-Subjectivity-Dynamics
- 四層構造による人間認知モデル
- 意味圧・整合・跳躍の数理モデル
- 基層的色付けによる生存優先処理

---

**構造主観力学（SSD）**: 宇宙のあらゆる現象を「安定と変化の動態」として理解するための統一理論